const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const PORT = process.env.PORT || 8080;
const ROOT = __dirname;
const TD_KEY = process.env.TWELVE_DATA_API_KEY || '';
const AV_KEY = process.env.ALPHA_VANTAGE_API_KEY || '';
const TE_KEY = process.env.TRADING_ECONOMICS_API_KEY || '';

function json(res, code, data){
  res.writeHead(code, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','Access-Control-Allow-Origin':'*'});
  res.end(JSON.stringify(data));
}
async function get(url){
  const r = await fetch(url, {headers:{'User-Agent':'ODERINDE-Gold-Intelligence/1.0'}});
  const text = await r.text();
  if(!r.ok) throw new Error(`Upstream ${r.status}: ${text.slice(0,200)}`);
  return JSON.parse(text);
}

async function candles(interval){
  if(!TD_KEY) return {configured:false, source:'Twelve Data', error:'TWELVE_DATA_API_KEY not configured'};
  const map={1m:'1min',5m:'5min',15m:'15min',30m:'30min',1h:'1h',4h:'4h',1d:'1day'};
  const i=map[interval]||'5min';
  const u=`https://api.twelvedata.com/time_series?symbol=XAU/USD&interval=${i}&outputsize=300&apikey=${encodeURIComponent(TD_KEY)}`;
  const d=await get(u);
  if(d.status==='error') throw new Error(d.message||'Twelve Data error');
  return {configured:true,source:'Twelve Data',interval,values:(d.values||[]).reverse()};
}
async function news(){
  if(!AV_KEY) return {configured:false,source:'Alpha Vantage',items:[],error:'ALPHA_VANTAGE_API_KEY not configured'};
  const u=`https://www.alphavantage.co/query?function=NEWS_SENTIMENT&tickers=FOREX:USD&topics=economy_macro,economy_monetary,financial_markets&sort=LATEST&limit=30&apikey=${encodeURIComponent(AV_KEY)}`;
  const d=await get(u);
  return {configured:true,source:'Alpha Vantage',items:(d.feed||[]).map(x=>({title:x.title,url:x.url,time:x.time_published,sentiment:x.overall_sentiment_label,score:Number(x.overall_sentiment_score||0)}))};
}
async function calendar(){
  if(!TE_KEY) return {configured:false,source:'Trading Economics',events:[],error:'TRADING_ECONOMICS_API_KEY not configured'};
  const now=new Date(); const end=new Date(now.getTime()+7*86400000);
  const f=d=>d.toISOString().slice(0,10);
  const u=`https://api.tradingeconomics.com/calendar/country/United States/${f(now)}/${f(end)}?c=${encodeURIComponent(TE_KEY)}&f=json`;
  const d=await get(u);
  return {configured:true,source:'Trading Economics',events:Array.isArray(d)?d.map(x=>({event:x.Event,country:x.Country,date:x.Date,importance:x.Importance,actual:x.Actual,forecast:x.Forecast,previous:x.Previous})):[]};
}
async function handler(req,res){
  const u=new URL(req.url,`http://${req.headers.host}`);
  try{
    if(u.pathname==='/api/health') return json(res,200,{ok:true,configured:{twelveData:!!TD_KEY,alphaVantage:!!AV_KEY,tradingEconomics:!!TE_KEY}});
    if(u.pathname==='/api/candles') return json(res,200,await candles(u.searchParams.get('interval')||'5m'));
    if(u.pathname==='/api/news') return json(res,200,await news());
    if(u.pathname==='/api/calendar') return json(res,200,await calendar());
    if(u.pathname==='/api/config') return json(res,200,{twelveData:!!TD_KEY,alphaVantage:!!AV_KEY,tradingEconomics:!!TE_KEY});
    let file=u.pathname==='/'?'/index.html':u.pathname;
    const full=path.join(ROOT,path.normalize(file));
    if(!full.startsWith(ROOT)) return json(res,403,{error:'forbidden'});
    if(fs.existsSync(full) && fs.statSync(full).isFile()){
      const ext=path.extname(full); const ct={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.txt':'text/plain; charset=utf-8'}[ext]||'application/octet-stream';
      res.writeHead(200,{'Content-Type':ct}); fs.createReadStream(full).pipe(res); return;
    }
    json(res,404,{error:'not found'});
  }catch(e){ json(res,502,{error:e.message}); }
}
http.createServer(handler).listen(PORT,()=>console.log(`ODERINDE listening on :${PORT}`));
